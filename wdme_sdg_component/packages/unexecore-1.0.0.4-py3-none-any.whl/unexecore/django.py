import copy
import logging

import unexecore.time
import unexecore.debug
import datetime


class django_logger(unexecore.debug.logger):

    def __init__(self):
        self.logger = logging.getLogger(__name__)

        self.data = []

    def log(self, text:str, level:str = 'INFO', module:str='n/a'):
        self.logger.warning( 'GARETH:'+unexecore.time.datetime_to_fiware(datetime.datetime.now()) +' ' + text)
        self.data.insert(0,{'date': datetime.datetime.now().replace(microsecond=0)
                             , 'message': text
                         ,'level': level
                        , 'module': module
                          }
                         )

        if len(self.data) > 100:
            self.data.pop(len(self.data)-1)

    def exception(self, e):
        self.log(unexecore.debug.exception_to_string(e))

    def get_data(self):
        return self.data

logger = django_logger()

def log(text, level:str = 'INFO', module:str='n/a'):
    logger.log(text, level, module)

def wsgilog_message(self, format, *args):
    logger.log(format % args,module='HTTP')

def logception(e):
    logger.log(unexecore.debug.exception_to_string(e),level='ERROR', module='?')


from django.core.servers.basehttp import WSGIRequestHandler
#WSGIRequestHandler.log_message = wsgilog_message


def parse_request(request) -> str:
    text = ''

    try:
        text += request.method + ' ' + request.path

        if len(request.query_params):
            text += '?'

            key_index = 0
            for key in request.query_params:
                # text += str(key_index) +' '
                text += key + '='

                param_list = request.GET.getlist(key)

                if len(param_list) > 1:
                    text += str(param_list)
                else:
                    text += param_list[0]

                if key_index < (len(request.query_params) - 1):
                    text += '&'

                key_index += 1

                # text += '\n'
    except Exception as e:
        text = 'Failed to parse request: ' + unexecore.debug.exception_to_string(e)

    try:
        if request.data != {}:
            text += ' BODY:'+ str(request.data)
    except Exception as e:
        text += ' Can\'t parse request body (as data)'

    return text

import django
def JsonResponse(request, result:any, response_code,module:str='UNDEFINED') -> django.http.JsonResponse:
    text = parse_request(request)

    text += ' RESPONSE:'
    text += str(response_code)

    unexecore.django.logger.log(text, level='INFO', module=module)

    return django.http.JsonResponse(result, safe=False, status = response_code)

def HttpResponse(request,response_code:int=500,module:str='UNDEFINED') -> django.http.HttpResponse:
    unexecore.django.logger.log("HTTP-RESPONSE:" + parse_request(request) + ' RESPONSE:' + str(response_code), level='INFO', module=module)
    return django.http.HttpResponse(status=response_code)

def ExceptionResponse(request, e:Exception, response_code=500, module:str='UNDEFINED') -> django.http.HttpResponse:
    unexecore.django.logger.log("HTTP-EXCEPTION:" + parse_request(request) + ' ' + unexecore.debug.exception_to_string(e) + ' RESPONSE:' + str(response_code), level='ERROR', module=module)
    return django.http.HttpResponse(status=response_code)

