from concurrent.futures import ProcessPoolExecutor
import multiprocessing
import threading
class ThreadProcessor:
    def __init__(self):
        self.worklist = []
        self.task_count = 0
    def run(self):
        for item in self.worklist:
            x = threading.Thread(target = self.do_task, args=(item, ))
            x.start()

    def run_as_debug(self):
        for item in self.worklist:
            self.do_task(item)

    def do_task(self, payload):
        pass

    def on_task_start(self):
        self.task_count += 1

    def on_task_end(self):
        self.task_count -= 1

    def is_working(self) -> bool:
        return self.task_count > 0

    def run_as_process_pool(self):
        with ProcessPoolExecutor(max_workers= int(multiprocessing.cpu_count()-1) ) as exe:
            exe.map(self.do_task, self.worklist)

